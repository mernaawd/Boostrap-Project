var peopleCard= document.querySelector('.card-title-1');
var ProjectsCard= document.querySelector('.card-title-2');
var ExperienceCard= document.querySelector('.card-title-3');
var Cofee_CupsCard= document.querySelector('.card-title-4');

function updateCounter1() {
    let count = 0;
    const interval = setInterval(() => {
      peopleCard.textContent = count +"+";
      count+=5;
      if (count > 90) {
        clearInterval(interval); 
      }
    }, 50); 
  }

updateCounter1();
function updateCounter2() {
    let count = 0;
    const interval = setInterval(() => {
      ProjectsCard.textContent = count ;
      count+=49;
      if (count > 2548) {
        clearInterval(interval); // Stop the counter when it reaches 10
      }
    }, 20); // Change the time interval (in milliseconds) between increments
  }
updateCounter2()

function updateCounter3() {
    let count = 0;
    const interval = setInterval(() => {
     ExperienceCard.textContent = count +"+" ;
      count+=5;
      if (count > 25) {
        clearInterval(interval); // Stop the counter when it reaches 10
      }
    },200); // Change the time interval (in milliseconds) between increments
  }
updateCounter3()
function updateCounter4() {
    let count = 0;
    const interval = setInterval(() => {
    Cofee_CupsCard.textContent = count ;
      count+=10;
      if (count > 256) {
        clearInterval(interval); // Stop the counter when it reaches 10
      }
    }, 50); // Change the time interval (in milliseconds) between increments
  }
  updateCounter4()
  const multipleItemCarousel = document.querySelector("#carouselExampleControls");

if (window.matchMedia("(min-width:576px)").matches) {
  const carousel = new bootstrap.Carousel(multipleItemCarousel, {
    interval: false
  });

  var carouselWidth = $(".carousel-inner")[0].scrollWidth;
  var cardWidth = $(".carousel-item").width();

  var scrollPosition = 0;

  $(".carousel-control-next").on("click", function () {
    if (scrollPosition < carouselWidth - cardWidth * 4) {
      scrollPosition = scrollPosition + cardWidth;
      $(".carousel-inner").animate({ scrollLeft: scrollPosition }, 600);
    }
  });
  $(".carousel-control-prev").on("click", function () {
    if (scrollPosition > 0) {
      scrollPosition = scrollPosition - cardWidth;
      $(".carousel-inner").animate({ scrollLeft: scrollPosition }, 600);
    }
  });
} else {
  $(multipleItemCarousel).addClass("slide");
}