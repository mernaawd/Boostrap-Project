//proxy

var obj = {
  name: "mai",
  age: 25,
};

obj.salary = 1000;
console.log(obj);

// obj.Age = 26;/

console.log(obj.hamada);

//proxy

//traps
handler = {
  //trap get
  get: function (target, prop, proxy) {
    console.log(arguments);
    if (!(prop in target)) {
      throw "this prop is not found";
    }
    // console.log(target[prop]);
    return target[prop]; //subscribe notation
  },

  //trap set
  set: function (target, prop, val, proxy) {
    console.log(arguments);
    if (!(prop in target)) {
      throw `this ${prop} is not found`;
    }
    // if(typeof val == typeof target[prop])
    if (prop == "age") {
      if (typeof val !== "number") {
        throw `prop must be number`;
      }
    }
    target[prop] = val;
  },
};
var p1 = new Proxy(obj, handler);
// var p2 = new Proxy(obj2 , handler)
// console.log(p1);
p1.name = "maiouy";
// p1.age = "hyugy";
console.log(p1, obj);
console.log(p1.name);
