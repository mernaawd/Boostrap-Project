//generator function

// function* generatorFunction() {
//   console.log("hii");
//   yield 10; //stop  {value : 10 , done:false}
//   //----------------------------------------
//   console.log("hello");
//   yield 4;
//   //--------------------------------------------

//   return 5;
//   //------------------------------------

//   //return {value : undefined , done:true}
// }

//even numbers 2-10

function* evenNumber() {
  //   yield 2;
  //   yield 4;
  //   yield 6;
  //   yield 8;
  //   yield 10;
  for (var i = 0; i <= 10; i += 2) {
    yield i;
  }
}

var res = evenNumber();
// console.log(res);
console.log(res.next());
console.log(res.next());
console.log(res.next());
console.log(res.next());
console.log(res.next());
console.log(res.next());
console.log(res.next());

//////////////fibonacci ///////////////

//0 1 1 2 3 5 8 13 ...

// function fib ()  // parameter -> 7 .. max number

//0 1 1 2 3 5

// function fib ()  // parameter -> 3
// 0 1 1
