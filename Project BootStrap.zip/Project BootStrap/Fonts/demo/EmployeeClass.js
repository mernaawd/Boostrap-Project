import { User } from "./UserClass.js";

export default class Employee extends User {
  constructor(n = "", a = 20, s) {
    // this.name = n;
    // this.age = a;
    super(n, a);
    this.salary = s;
  }
  //private member
  #myPrivateMember = 10;

  get myPrivateMember() {
    return this.#myPrivateMember;
  }
  set myPrivateMember(v) {
    this.#myPrivateMember = v;
  }

  calc() {
    console.log("hello");
  }

  displayInfo() {
    console.log("wew");
  }
  //static member
  static x = 10;

  //static method
  static toString() {
    return `my name is ${this.name} and my age is ${this.age}`;
  }
}
