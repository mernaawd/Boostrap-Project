export class User {
  constructor(n, a) {
    //Abstract class
    if (this.constructor == User) {
      throw "this is an abstract class";
    }
    this.name = n;
    this.age = a;
    //method
  }

  displayInfo() {
    console.log(this.name, this.age);
  }
}












