// class
// modules
// proxy
// iterator - generator - symbol

///////////////////////////////////////////
// constructor function
// function User(n, a) {
//   this.name = n;
//   this.age = a;
// }
// function Employee(n, a, s) {
//   User.call(this, n, a, s);
//   this.salary = s;
// }

// Employee.prototype.calc = function () {
//   console.log("hello");
// };

// var emp = new Employee("mai", 20, 2000);
// console.log(emp);

//Babel
//syntax sugar
export class User {
  constructor(n, a) {
    //Abstract class
    if (this.constructor == User) {
      throw "this is an abstract class";
    }
    this.name = n;
    this.age = a;
    //method
  }

  displayInfo() {
    console.log(this.name, this.age);
  }
}

// var u = new User("mai", 33); //{constructor : User}
// var u2 = new User("mai", 33); //{constructor : User}
// var u3 = new User("mai", 33); //{constructor : User}
// console.log(u);

/////////////////////////////
// Inheritance
//1- keyword extends -> class
//2- super() -> initial values
export class Employee extends User {
  constructor(n = "", a = 20, s) {
    // this.name = n;
    // this.age = a;
    super(n, a);
    this.salary = s;
  }
  //private member
  #myPrivateMember = 10;

  get myPrivateMember() {
    return this.#myPrivateMember;
  }
  set myPrivateMember(v) {
    this.#myPrivateMember = v;
  }

  calc() {
    console.log("hello");
  }

  displayInfo() {
    console.log("wew");
  }
  //static member
  static x = 10;

  //static method
  static toString() {
    return `my name is ${this.name} and my age is ${this.age}`;
  }
}
Employee.prototype.display = function () {
  console.log("hi");
};
var emp = new Employee("hamada", 24);
console.log(emp);
emp.calc();
emp.display();

//static variable
// Employee.x

// //static method
// Employee.calcSalary = function(){
//     console.log(this.salary + 33);
// }

export class Student extends User {
  constructor(n = "", a = 20, s) {
    // this.name = n;
    // this.age = a;
    super(n, a);
    this.grades = s;
  }
}

// export - import
