var arr = [1, 2, 3];

var arr2 = [...arr];

var str = "mmai";
// console.dir(str);
// var obj = {
//   name: "mai",
//   age: 22,
// };

// for (var ele of obj) {
//   console.log(ele);
// }

///////////////////////////
//Symbol -> primitive type

var s1 = Symbol("my var"); //0x10
var s2 = Symbol("my var"); //0x20
var s3 = Symbol("my var"); //0x40
var s4 = Symbol(); //0x50

// console.log(s1 === s2);
/////////
var key = "name";
var obj2 = {
  age: 22,
  [key]: "mai",
  [s1]: function () {
    console.log("hello");
  },
  [Symbol("my property")]: function () {
    console.log("bye");
  },
};
// obj2[Symbol("my property")]();
// console.log(obj2[s1]());

for (var x in obj2) {
  console.log(x);
}

// var res = arr[Symbol.iterator]();

// console.log(res.next()); {value: 1 , done: false }
// console.log(res.next()); {value: 2 , done: false }
// console.log(res.next()); {value: 3 , done: false }
// console.log(res.next());
// console.log(res.next());

// function [Symbol.iterator]
// return object has function next()
// next() -> return object{value: 1 , done: false }

//structure
// function iterator() {
//   return {
//     next: function () {
//       return {
//         value: 1,
//         done: false,
//       };
//     },
//   };
// }

// var res = iterator();
// console.log(res.next());
// console.log(res.next());
// console.log(res.next());

// function -> even numbers 0-10
// arr[Symbol.iterator] = iterator;
// function iterator() {
//   var counter = 0;
//   return {
//     next: function () {
//       counter += 2;
//       if (counter <= 10) {
//         return {
//           value: counter,
//           done: false,
//         };
//       } else {
//         return {
//           value: undefined,
//           done: true,
//         };
//       }
//     },
//   };
// }

// var res = iterator();
// console.log(res.next());
// console.log(res.next());
// console.log(res.next());
// console.log(res.next());
// console.log(res.next());
// console.log(res.next());
// console.log(res.next());

// for ( var i of arr){
//     console.log(i);
// }

//////////////////////////
//function iterator -> obj -> [key , value]
var obj = {
  name: "mai",
  age: 22,
  [Symbol.iterator]: objIterator,
};

// obj[salary] = 1000;
// obj[Symbol.iterator] = objIterator;

var res = obj[Symbol.iterator]();
function objIterator() {
  var keys = Object.keys(this); //['name', 'age']
  console.log(keys);
  var counter = -1;
  //self pattern
  var self = this; //self pattern
  return {
    next: () => {
      counter++; //closure
      //   for (var i = 0; i < keys.length; i++) {
      //     return {
      //       value: [keys[i], this[keys[i]]], // obj[name] //["name" , "mai"]  -> ["age" : 22]
      //       done: false,
      //     };
      //   }

      if (counter < keys.length) {
        return {
          value: [keys[counter], self[keys[counter]]], // obj[name] //["name" , "mai"]  -> ["age" : 22]
          done: false,
        };
      } else {
        return {
          value: undefined,
          done: true,
        };
      }
    },
  };
}

console.log(res.next());
console.log(res.next());
console.log(res.next());
console.log(res.next());
console.log(res.next());

// for (var i of obj) {
//   console.log(i); // [key , value]
// }
