// import { Student as S } from "./script.js";
// import { User } from "./UserClass.js";
// import { User as U, Student } from "./script";
// import * as classes from "./script.js";

// import { Employee } from "./EmployeeClass.js";
import hamada from "./EmployeeClass.js";

// var student1 = new classes.Student("mai", 23, 60);
// console.log(student1);

var emp1 = new hamada("mm", 22, 222);
console.log({ emp1 });
